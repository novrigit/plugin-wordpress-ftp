**just proof of concept to answer question on wpse**
